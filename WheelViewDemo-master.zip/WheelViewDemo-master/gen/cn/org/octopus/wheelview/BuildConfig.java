/** Automatically generated file. DO NOT MODIFY */
package cn.org.octopus.wheelview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}