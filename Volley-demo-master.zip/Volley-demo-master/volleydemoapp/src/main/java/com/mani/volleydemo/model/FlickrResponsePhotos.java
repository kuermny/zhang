package com.mani.volleydemo.model;


public class FlickrResponsePhotos {

	FlickrResponse photos;
		
	public FlickrResponse getPhotos() {
		return photos;
	}

	public void setPhotos(FlickrResponse photos) {
		this.photos = photos;
	}

}
